"""Top-level package for Python Boilerplate."""

__author__ = "Saman Zand Haghighi"
__email__ = "samanzandh@gmail.com"
__version__ = "0.0.2"
