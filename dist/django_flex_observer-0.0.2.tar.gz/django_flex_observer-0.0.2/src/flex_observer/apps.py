from django.apps import AppConfig


class FlexObserverConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "flex_observer"
