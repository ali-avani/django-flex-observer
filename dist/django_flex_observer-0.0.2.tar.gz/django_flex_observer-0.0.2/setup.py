if __name__ == "__main__":
    import setuptools

    setuptools.setup()
